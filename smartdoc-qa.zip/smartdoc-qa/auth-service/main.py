"""
main.py - Auth Service (port 8000)
------------------------------------
Handles user registration, login, and JWT issuance.

Architecture note:
  Other services validate JWTs locally using the shared JWT_SECRET.
  They do NOT call this service on every request - avoids synchronous
  dependency and keeps latency low.
"""
from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from pymongo.errors import DuplicateKeyError

from database import get_db, init_db
from models import UserCreate, UserLogin, TokenResponse, UserPublic
from security import hash_password, verify_password, create_access_token
from dependencies import get_current_user

app = FastAPI(
    title="SmartDoc - Auth Service",
    description="Handles user registration, login, and JWT issuance.",
    version="1.0.0",
)

# CORS: In production, replace '*' with your actual frontend domain.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True,
    allow_methods=["*"], allow_headers=["*"],
)


@app.on_event("startup")
async def startup():
    """Run once on boot - create DB indexes."""
    await init_db()


@app.post("/auth/register", response_model=TokenResponse, status_code=201)
async def register(user: UserCreate, db=Depends(get_db)):
    """
    Register a new user.
    1. Validate input (Pydantic)
    2. Hash password - plaintext never stored
    3. Insert to MongoDB - unique index catches duplicate emails
    4. Return JWT so user is immediately logged in
    """
    hashed = hash_password(user.password)
    try:
        result = await db.users.insert_one({
            "name": user.name,
            "email": user.email,
            "password": hashed,
        })
    except DuplicateKeyError:
        raise HTTPException(status.HTTP_409_CONFLICT, "An account with this email already exists.")

    token = create_access_token(str(result.inserted_id), user.email)
    return TokenResponse(access_token=token, user_id=str(result.inserted_id), email=user.email, name=user.name)


@app.post("/auth/login", response_model=TokenResponse)
async def login(credentials: UserLogin, db=Depends(get_db)):
    """
    Authenticate user.
    Security: single error message for wrong email OR password
    to prevent user enumeration attacks.
    """
    user = await db.users.find_one({"email": credentials.email})
    if not user or not verify_password(credentials.password, user["password"]):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid email or password.")

    token = create_access_token(str(user["_id"]), user["email"])
    return TokenResponse(access_token=token, user_id=str(user["_id"]), email=user["email"], name=user["name"])


@app.get("/auth/me", response_model=UserPublic)
async def get_me(current_user: dict = Depends(get_current_user)):
    """Return identity of the authenticated user. Protected by JWT."""
    return UserPublic(**current_user)


@app.get("/health")
def health():
    return {"status": "ok", "service": "auth-service"}
