"""
database.py - Auth Service
---------------------------
Async MongoDB connection using Motor.
Single client instance = shared connection pool.
Indexes created on startup for query performance.
"""
import os
from motor.motor_asyncio import AsyncIOMotorClient

MONGO_URL = os.environ["MONGO_URL"]
DB_NAME = "smartdoc_auth"

_client = AsyncIOMotorClient(MONGO_URL)
_db = _client[DB_NAME]


async def init_db():
    """
    Called on app startup. Creates indexes for frequent query fields.
    Index on 'email' with unique=True: fast login + duplicate prevention.
    """
    await _db.users.create_index("email", unique=True)


async def get_db():
    """FastAPI dependency that yields the database instance."""
    yield _db
