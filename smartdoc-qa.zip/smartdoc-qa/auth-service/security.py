"""
security.py - Auth Service
--------------------------
Centralises all cryptographic operations:
  - Password hashing using bcrypt (industry standard, salted)
  - JWT creation and verification
"""
import os
import jwt
from datetime import datetime, timedelta
from passlib.context import CryptContext

pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")

# JWT secret MUST come from environment - never a hardcoded fallback in prod.
SECRET_KEY = os.environ["JWT_SECRET"]
ALGORITHM = "HS256"
TOKEN_EXPIRE_HOURS = int(os.getenv("TOKEN_EXPIRE_HOURS", "24"))


def hash_password(plain: str) -> str:
    """Hash a plaintext password using bcrypt. Always store the hash, never the plain text."""
    return pwd_ctx.hash(plain)


def verify_password(plain: str, hashed: str) -> bool:
    """Verify a plaintext password against a stored bcrypt hash. Timing-safe."""
    return pwd_ctx.verify(plain, hashed)


def create_access_token(user_id: str, email: str) -> str:
    """
    Create a signed JWT containing user identity.
    Payload: sub (user_id), email, exp (expiry), iat (issued-at).
    """
    payload = {
        "sub": user_id,
        "email": email,
        "exp": datetime.utcnow() + timedelta(hours=TOKEN_EXPIRE_HOURS),
        "iat": datetime.utcnow(),
    }
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


def decode_access_token(token: str) -> dict:
    """
    Decode and validate a JWT.
    Raises jwt.ExpiredSignatureError or jwt.InvalidTokenError on failure.
    """
    return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
