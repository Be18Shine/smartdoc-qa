"""
dependencies.py - Auth Service
-------------------------------
FastAPI dependency injection for authentication.
Use Depends(get_current_user) on any route to protect it.
"""
import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from security import decode_access_token
from database import get_db

bearer_scheme = HTTPBearer()


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
    db=Depends(get_db),
) -> dict:
    """
    Validates JWT and returns current user dict.
    Raises HTTP 401 if token is missing, expired, or invalid.
    """
    try:
        payload = decode_access_token(credentials.credentials)
        user_id = payload["sub"]
    except jwt.ExpiredSignatureError:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Token has expired. Please log in again.")
    except jwt.InvalidTokenError:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid token. Authentication failed.")

    from bson import ObjectId
    user = await db.users.find_one({"_id": ObjectId(user_id)})
    if not user:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "User account not found.")

    # Return safe dict - never include password hash downstream
    return {"user_id": user_id, "email": payload["email"], "name": user.get("name")}
