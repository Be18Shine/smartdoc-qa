# SmartDoc Q&A

> Gen-AI powered document question-answering system built on a
> 3-service FastAPI microservices architecture.

---

## Architecture

```
┌─────────────┐     JWT      ┌──────────────────┐
│   Client    │ ──────────▶  │  Auth Service    │  :8000
│  (Browser)  │              │  FastAPI + Mongo  │
└─────────────┘              └──────────────────┘
       │
       │ JWT (all requests)
       ▼
┌──────────────────┐   HTTP    ┌──────────────────┐
│ Document Service │ ◀──────── │    QA Service    │  :8002
│ FastAPI + Mongo  │  /chunks  │ FastAPI + Claude  │
└──────────────────┘           └──────────────────┘
       :8001
```

## Services

| Service | Port | Role |
|---------|------|------|
| auth-service | 8000 | Registration, login, JWT issuance |
| document-service | 8001 | Upload, chunk, store documents |
| qa-service | 8002 | Retrieve chunks, generate AI answers |

## Tech Stack

- **Python 3.11** + **FastAPI** — async REST APIs, auto Swagger docs
- **MongoDB** + **Motor** — async document storage for users and chunks
- **Claude API (Anthropic)** — LLM for natural language Q&A
- **JWT (HS256)** — stateless auth shared across services
- **Docker + Docker Compose** — containerised, reproducible deployment
- **Pydantic v2** — runtime validation and API schema generation

## Key Design Patterns

### RAG (Retrieval-Augmented Generation)
Documents are chunked on upload. On each question, the most relevant
chunks are retrieved via keyword scoring and injected into Claude's
context window — accurate, fast, and cost-efficient.

### JWT Stateless Auth
All services share JWT_SECRET. Each service validates tokens locally —
no network call to auth-service per request. Low latency, no single point of failure.

### Dependency Injection
FastAPI Depends() centralises auth. One line protects any route.

### Fail-Fast Configuration
Secrets read from env without fallbacks. Missing config = immediate
startup failure with a clear error.

## Quick Start

```bash
# 1. Clone
git clone https://github.com/YOUR_USERNAME/smartdoc-qa.git
cd smartdoc-qa

# 2. Configure
cp .env.example .env
# Edit .env — add ANTHROPIC_API_KEY and set JWT_SECRET

# 3. Run
docker-compose up --build

# 4. Explore
open http://localhost:8000/docs   # Auth Service Swagger
open http://localhost:8001/docs   # Document Service Swagger
open http://localhost:8002/docs   # QA Service Swagger
```

## API Flow

```
1. POST /auth/register         → { access_token }
2. POST /documents/upload      → { document_id, chunk_count }   [Bearer token]
3. POST /qa/ask                → { answer, chunks_used }        [Bearer token]
```

## Future Improvements

| Area | Current | Upgrade |
|------|---------|---------|
| Chunk retrieval | Keyword scoring | Vector embeddings + cosine similarity |
| Rate limiting | None | slowapi middleware per user/IP |
| Observability | /health only | OpenTelemetry tracing across services |
| Testing | None | pytest + httpx TestClient per service |
| CI/CD | None | GitHub Actions → build, test, push to registry |

## License

MIT
