"""
dependencies.py - Document Service
------------------------------------
JWT validation dependency - mirrors auth-service/dependencies.py.
Each service validates tokens locally (no network call to auth-service).
"""
import jwt
import os
from fastapi import Depends, HTTPException, status, Header
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import Optional

SECRET_KEY = os.environ["JWT_SECRET"]
ALGORITHM = "HS256"
bearer_scheme = HTTPBearer()


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
) -> dict:
    """Validate JWT and return user payload. Raises 401 on failure."""
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        return {"user_id": payload["sub"], "email": payload["email"]}
    except jwt.ExpiredSignatureError:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Token has expired.")
    except jwt.InvalidTokenError:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid token.")


async def get_auth_header(
    authorization: Optional[str] = Header(None)
) -> str:
    """Return raw Authorization header string for forwarding to other services."""
    if not authorization:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Missing Authorization header.")
    return authorization
