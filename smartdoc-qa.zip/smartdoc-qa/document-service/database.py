"""
database.py - Document Service
--------------------------------
Async MongoDB connection. Index on user_id for fast per-user queries.
"""
import os
from motor.motor_asyncio import AsyncIOMotorClient

MONGO_URL = os.environ["MONGO_URL"]
DB_NAME = "smartdoc_docs"

_client = AsyncIOMotorClient(MONGO_URL)
_db = _client[DB_NAME]


async def init_db():
    """Create index on user_id - speeds up listing a user's documents."""
    await _db.documents.create_index("user_id")


async def get_db():
    yield _db
