"""
main.py - Document Service (port 8001)
----------------------------------------
Handles document upload, text chunking, and chunk storage.

Design decisions:
  - Chunks stored inline in document record (suitable for docs up to ~1MB).
    For larger docs, split into a separate 'chunks' collection.
  - File size capped at 5MB to prevent memory exhaustion.
  - JWT validated locally - no call to auth-service per request.
  - user_id filter on all queries enforces document ownership.
"""
from fastapi import FastAPI, UploadFile, File, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime
from bson import ObjectId

from database import get_db, init_db
from chunker import chunk_text
from dependencies import get_current_user
from models import DocumentOut, ChunksOut

MAX_FILE_BYTES = 5 * 1024 * 1024  # 5 MB hard limit

app = FastAPI(
    title="SmartDoc - Document Service",
    description="Handles document upload, chunking, and storage.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware, allow_origins=["*"],
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)


@app.on_event("startup")
async def startup():
    await init_db()


@app.post("/documents/upload", response_model=DocumentOut, status_code=201)
async def upload_document(
    file: UploadFile = File(...),
    current_user: dict = Depends(get_current_user),
    db=Depends(get_db),
):
    """
    Upload and index a document.
    Pipeline: validate -> decode -> chunk -> persist -> return metadata.
    """
    content = await file.read()

    if len(content) > MAX_FILE_BYTES:
        raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                            f"File exceeds {MAX_FILE_BYTES // 1024 // 1024}MB limit.")

    try:
        text = content.decode("utf-8")
    except UnicodeDecodeError:
        raise HTTPException(status.HTTP_415_UNSUPPORTED_MEDIA_TYPE, "File must be UTF-8 encoded text.")

    if not text.strip():
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "Document is empty.")

    chunks = chunk_text(text, chunk_size=300, overlap=50)

    doc = {
        "user_id": current_user["user_id"],
        "filename": file.filename,
        "file_size_bytes": len(content),
        "chunk_count": len(chunks),
        "chunks": chunks,
        "uploaded_at": datetime.utcnow(),
    }
    result = await db.documents.insert_one(doc)

    return DocumentOut(
        document_id=str(result.inserted_id),
        filename=file.filename,
        file_size_bytes=len(content),
        chunk_count=len(chunks),
        uploaded_at=doc["uploaded_at"],
    )


@app.get("/documents", response_model=list[DocumentOut])
async def list_documents(current_user: dict = Depends(get_current_user), db=Depends(get_db)):
    """List all documents for authenticated user. Excludes chunks for lean response."""
    cursor = db.documents.find({"user_id": current_user["user_id"]}, {"chunks": 0})
    docs = []
    async for doc in cursor:
        docs.append(DocumentOut(
            document_id=str(doc["_id"]),
            filename=doc["filename"],
            file_size_bytes=doc["file_size_bytes"],
            chunk_count=doc["chunk_count"],
            uploaded_at=doc["uploaded_at"],
        ))
    return docs


@app.get("/documents/{doc_id}/chunks", response_model=ChunksOut)
async def get_chunks(doc_id: str, current_user: dict = Depends(get_current_user), db=Depends(get_db)):
    """Return all chunks for a document. Called by QA service during Q&A."""
    try:
        oid = ObjectId(doc_id)
    except Exception:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Invalid document ID.")

    doc = await db.documents.find_one({"_id": oid, "user_id": current_user["user_id"]})
    if not doc:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Document not found.")

    return ChunksOut(document_id=doc_id, filename=doc["filename"], chunks=doc["chunks"])


@app.delete("/documents/{doc_id}", status_code=204)
async def delete_document(doc_id: str, current_user: dict = Depends(get_current_user), db=Depends(get_db)):
    """Delete a document. user_id filter ensures ownership."""
    try:
        oid = ObjectId(doc_id)
    except Exception:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Invalid document ID.")

    result = await db.documents.delete_one({"_id": oid, "user_id": current_user["user_id"]})
    if result.deleted_count == 0:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Document not found.")


@app.get("/health")
def health():
    return {"status": "ok", "service": "document-service"}
