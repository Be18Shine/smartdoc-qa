"""
chunker.py - Document Service
------------------------------
Converts raw document text into overlapping chunks for LLM context injection.

Why chunk?
  LLMs have finite context windows. We split text so the QA service
  can select only the most relevant pieces per question.

Why overlapping chunks?
  Sentences spanning chunk boundaries are fully captured in at least
  one chunk. Example (size=5, overlap=2):
    Input : "A B C D E F G H"
    Chunk1: "A B C D E"
    Chunk2: "D E F G H"  <- D,E repeated from chunk1
"""


def chunk_text(text: str, chunk_size: int = 300, overlap: int = 50) -> list[str]:
    """
    Split text into overlapping word-based chunks.

    Args:
        text:       Raw document text.
        chunk_size: Max words per chunk.
        overlap:    Words repeated between consecutive chunks.

    Returns:
        List of text chunk strings.
    """
    if not text or not text.strip():
        return []

    words = text.split()

    # Entire document fits in one chunk - no need to split
    if len(words) <= chunk_size:
        return [text.strip()]

    chunks = []
    step = chunk_size - overlap

    for i in range(0, len(words), step):
        chunk = " ".join(words[i: i + chunk_size]).strip()
        if chunk:
            chunks.append(chunk)
        if i + chunk_size >= len(words):
            break

    return chunks
