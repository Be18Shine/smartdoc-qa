"""
models.py - Document Service
-----------------------------
Pydantic schemas for document upload responses and chunk retrieval.
"""
from pydantic import BaseModel
from datetime import datetime


class DocumentOut(BaseModel):
    """Response schema for document metadata - excludes raw chunks."""
    document_id: str
    filename: str
    file_size_bytes: int
    chunk_count: int
    uploaded_at: datetime


class ChunksOut(BaseModel):
    """Response schema when QA service fetches chunks for a document."""
    document_id: str
    filename: str
    chunks: list[str]
