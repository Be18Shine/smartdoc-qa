"""
main.py - QA Service (port 8002)
----------------------------------
Orchestrates the full RAG (Retrieval-Augmented Generation) pipeline:

  [Client] -> POST /qa/ask
      -> Fetch chunks from Document Service (HTTP)
      -> retriever.py scores and selects top-K relevant chunks
      -> claude_client.py sends context + question to Claude
      -> Returns structured answer with metadata

RAG pattern:
  Rather than passing the full document to the LLM (expensive, hits context
  limits), we retrieve only relevant portions. This is the foundation of
  every production document Q&A system.

Inter-service communication:
  Calls Document Service over HTTP. Forwards the user's JWT in the
  Authorization header - Document Service validates it independently.
  No shared DB access between services (microservices own their data).
"""
from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
import httpx
import os

from dependencies import get_current_user, get_auth_header
from models import QuestionRequest, AnswerResponse
from retriever import retrieve_top_chunks
from claude_client import get_ai_answer

DOCUMENT_SERVICE_URL = os.environ["DOCUMENT_SERVICE_URL"]

app = FastAPI(
    title="SmartDoc - QA Service",
    description="AI-powered Q&A over uploaded documents via Claude.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware, allow_origins=["*"],
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)


@app.post("/qa/ask", response_model=AnswerResponse)
async def ask_question(
    req: QuestionRequest,
    current_user: dict = Depends(get_current_user),
    auth_header: str = Depends(get_auth_header),
):
    """
    Full RAG pipeline endpoint.
    Step 1: Fetch document chunks from Document Service.
    Step 2: Score and retrieve most relevant chunks (retriever.py).
    Step 3: Generate answer with Claude (claude_client.py).
    """
    # Step 1 - fetch chunks via inter-service HTTP call
    async with httpx.AsyncClient(timeout=10.0) as client:
        resp = await client.get(
            f"{DOCUMENT_SERVICE_URL}/documents/{req.document_id}/chunks",
            headers={"Authorization": auth_header},
        )

    if resp.status_code == 404:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Document not found.")
    if resp.status_code == 401:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Not authorised to access this document.")
    if resp.status_code != 200:
        raise HTTPException(status.HTTP_502_BAD_GATEWAY, "Document service unavailable.")

    data = resp.json()
    all_chunks: list[str] = data["chunks"]
    filename: str = data["filename"]

    # Step 2 - keyword-scored retrieval (swap for vector search in production)
    relevant_chunks = retrieve_top_chunks(all_chunks, req.question, top_k=6)
    context = "\n\n---\n\n".join(relevant_chunks)

    # Step 3 - generate answer via Claude
    try:
        answer = await get_ai_answer(question=req.question, context=context, filename=filename)
    except RuntimeError as e:
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, str(e))

    return AnswerResponse(
        question=req.question,
        answer=answer,
        document_id=req.document_id,
        filename=filename,
        chunks_used=len(relevant_chunks),
        total_chunks=len(all_chunks),
    )


@app.get("/health")
def health():
    return {"status": "ok", "service": "qa-service"}
