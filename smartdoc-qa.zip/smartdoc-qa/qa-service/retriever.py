"""
retriever.py - QA Service
--------------------------
Selects the most relevant document chunks for a given question.

Why not just take first N chunks?
  The answer to "What is the refund policy?" might be on page 8.
  Sending the first 8 chunks would return "I don't know."

Strategy: TF-IDF-inspired keyword scoring.
  Count how many question keywords appear in each chunk.
  Highest overlap = most likely to contain the answer.

Production upgrade path:
  Replace with vector similarity search (pgvector / Pinecone).
  Only this file changes - the rest of the system is already architected for it.
"""
import re
from collections import Counter

STOP_WORDS = {
    "a","an","the","is","it","in","on","at","to","of","and","or",
    "for","with","this","that","are","was","were","be","been","have",
    "has","had","do","does","did","will","would","could","should","may",
    "what","how","why","when","where","who","which","i","my","your",
}


def tokenize(text: str) -> list[str]:
    """Lowercase, strip punctuation, remove stop words."""
    tokens = re.findall(r"\b[a-z]+\b", text.lower())
    return [t for t in tokens if t not in STOP_WORDS]


def score_chunk(chunk: str, query_tokens: list[str]) -> int:
    """Score a chunk by counting query token matches."""
    chunk_tokens = Counter(tokenize(chunk))
    return sum(chunk_tokens[qt] for qt in query_tokens)


def retrieve_top_chunks(chunks: list[str], question: str, top_k: int = 6) -> list[str]:
    """
    Return top_k most relevant chunks for a question.
    Falls back to first top_k chunks if question has no meaningful tokens.
    """
    query_tokens = tokenize(question)
    if not query_tokens:
        return chunks[:top_k]

    scored = [(score_chunk(c, query_tokens), i, c) for i, c in enumerate(chunks)]
    scored.sort(key=lambda x: (-x[0], x[1]))
    return [c for _, _, c in scored[:top_k]]
