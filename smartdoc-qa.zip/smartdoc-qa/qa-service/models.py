"""
models.py - QA Service
-----------------------
Request and response schemas for the Q&A API.
"""
from pydantic import BaseModel, field_validator


class QuestionRequest(BaseModel):
    document_id: str
    question: str

    @field_validator("question")
    @classmethod
    def question_valid(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("Question cannot be empty.")
        if len(v) > 1000:
            raise ValueError("Question must be under 1000 characters.")
        return v.strip()


class AnswerResponse(BaseModel):
    question: str
    answer: str
    document_id: str
    filename: str
    chunks_used: int      # chunks sent to Claude (for observability)
    total_chunks: int     # total chunks in the document
