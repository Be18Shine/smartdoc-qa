"""
claude_client.py - QA Service
------------------------------
Thin wrapper around the Anthropic Python SDK.

Design:
  - Single client instance at module level (connection pooling).
  - System prompt constrains Claude to document content only - prevents hallucination.
  - asyncio.to_thread() wraps the sync SDK call to avoid blocking the event loop.
"""
import os
import asyncio
import anthropic

_client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])

MODEL = "claude-opus-4-5"
MAX_TOKENS = 1024


def _build_system_prompt(filename: str) -> str:
    """
    Ground Claude strictly in the document content.
    Key rules: no external knowledge, explicit uncertainty, no hallucination.
    """
    return f"""You are SmartDoc AI, an intelligent document Q&A assistant.
You are answering questions about: "{filename}"

Rules:
1. Answer ONLY based on the provided content. Do not use external knowledge.
2. If the answer is not in the content, say: "I could not find that in this document."
3. Be concise. Use bullet points for lists.
4. Quote directly from the document when relevant (use quotation marks).
5. Never fabricate facts, statistics, or details not present in the content.
"""


async def get_ai_answer(question: str, context: str, filename: str) -> str:
    """
    Send question + document context to Claude and return the answer.

    asyncio.to_thread: Anthropic SDK is synchronous. This runs it in a
    thread pool so FastAPI's event loop stays non-blocked.
    """
    def _call():
        return _client.messages.create(
            model=MODEL,
            max_tokens=MAX_TOKENS,
            system=_build_system_prompt(filename),
            messages=[{
                "role": "user",
                "content": f"Document content:\n\n{context}\n\n---\n\nQuestion: {question}"
            }],
        )

    try:
        response = await asyncio.to_thread(_call)
        return response.content[0].text
    except anthropic.APIConnectionError:
        raise RuntimeError("Failed to connect to Claude API.")
    except anthropic.RateLimitError:
        raise RuntimeError("Claude API rate limit reached. Retry shortly.")
    except anthropic.APIStatusError as e:
        raise RuntimeError(f"Claude API error {e.status_code}: {e.message}")
